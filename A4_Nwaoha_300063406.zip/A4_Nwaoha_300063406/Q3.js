function main() {
	var clicks = document.getElementsByClassName('clickable');

	for(i = 0; i < clicks.length; ++i) {
		clicks[i].onclick = function(event) {
            event.preventDefault();
			event.stopPropagation();
			if(event.shiftKey)
				alert("Event name: "+event);

			else if(event.ctrlKey)
				alert("Tag name: "+this.tagName);
		};
	} 
}

main();