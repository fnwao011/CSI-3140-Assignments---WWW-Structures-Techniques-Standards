var omnaEl,dragData=null;
      function window_onload() {
        omnaEl=document.getElementById("sah")
        if(window.addEventListener) {
           omnaEl.addEventListener('mousedown',startDrag,false);
           document.body.addEventListener('mousemove',drag,false);
           document.body.addEventListener('mouseup',stopDrag,false);
        }
        else if(window.attachEvent) {
           omnaEl.attachEvent('onmousedown',startDrag);
           document.body.attachEvent('onmousemove',drag);
           document.body.attachEvent('onmouseup',stopDrag);
        }
      }


      function startDrag(ev) {
        if(!dragData) {
          ev=ev||event;
          dragData={
            x: ev.clientX-omnaEl.offsetLeft,
            y: ev.clientY-omnaEl.offsetTop
          };
        };
      }
      function drag(ev) {
        if(dragData) {
          ev=ev||event;
          omnaEl.style.left=ev.clientX-dragData.x+"px";
          omnaEl.style.top=ev.clientY-dragData.y+"px";
        }
      }
      function stopDrag(ev) {
        if(dragData) {
          ev=ev||event;
          omnaEl.style.left=ev.clientX-dragData.x+"px";
          omnaEl.style.top=ev.clientY-dragData.y+"px";
          dragData=null;
        }
      }