function main() {

	var canv = document.getElementById('canvas');
	var context = canv.getContext('2d');

	//makes gradient
	var grad = context.createLinearGradient(100, 100, 100, 400);
	grad.addColorStop(0, 'red');
	grad.addColorStop(0.4, 'yellow');
	grad.addColorStop(1, 'blue');

	
	context.beginPath();
	context.moveTo(200, 100);
	context.lineTo(150, 400);
	context.lineTo(400, 400);

	
	context.fillStyle = grad;
	context.fill();

}

main();