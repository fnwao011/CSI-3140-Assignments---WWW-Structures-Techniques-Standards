var emptybox;
var numOfMoves;
var isFibished = false;
var time = 0;
var nums = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16];


function startPuzzle() {
    numOfMoves = 0;
    isSolved = false;

    for (var i = 0; i < 16; i++) {
        var tmp = document.getElementById(i);
        tmp.className = "cell ";
    }

    randomNumber = nums.sort(function() {
        return (Math.round(Math.random()) - 0.5);
    });
    while (!Problem.prototype.is_solvable(randomNumber)) {
        randomNumber = nums.sort(function() {
            return (Math.round(Math.random()) - 0.5);
        });
    }

    for (var i = 0; i < 16; i++) {
        var tmp = document.getElementById(i);
        if (randomNumber[i] == 16) {
            tmp.className = "cell empty";
            tmp.innerHTML = "";
            emptybox = i;
        } else
            tmp.innerHTML = randomNumber[i];
    }

}




function cellClicked(x) {
    if (isSolved)
        return;

    if (x.id != emptybox + '') {
        var emptyI = Math.floor(emptybox / 4);
        var emptyJ = emptybox % 4;
        var id_selected = Number(x.id);
        var selectedI = Math.floor(id_selected / 4);
        var selectedJ = id_selected % 4;

        if ((Math.abs(emptyI - selectedI) == 1 && emptyJ == selectedJ) ||
            (Math.abs(emptyJ - selectedJ) == 1 && emptyI == selectedI)) {

            document.getElementById(emptybox).className = "cell";
            document.getElementById(emptybox).innerHTML = x.innerHTML;

            x.className = "cell empty";
            x.innerHTML = '';

            emptybox = id_selected;
            numOfMoves++;

            document.getElementById("moves").innerHTML = "Num of Moves: " + numOfMoves;

            if (isDone()) {
                isSolved = true;
                document.getElementById("moves").innerHTML = "CONGRATS! It Took This Many Moves: " + numOfMoves;
            }
        }
    }
}

function isDone() {
    return document.getElementById('0').innerHTML == '1' &&
        document.getElementById('1').innerHTML == '2' &&
        document.getElementById('2').innerHTML == '3' &&
        document.getElementById('3').innerHTML == '4' &&
        document.getElementById('4').innerHTML == '5' &&
        document.getElementById('5').innerHTML == '6' &&
        document.getElementById('6').innerHTML == '7' &&
        document.getElementById('7').innerHTML == '8' &&
        document.getElementById('8').innerHTML == '9' &&
        document.getElementById('9').innerHTML == '10' &&
        document.getElementById('10').innerHTML == '11' &&
        document.getElementById('11').innerHTML == '12' &&
        document.getElementById('12').innerHTML == '13' &&
        document.getElementById('13').innerHTML == '14' &&
        document.getElementById('14').innerHTML == '15';
}


function lastClick() {
    var curr_state = currentState();
    var problem = new Problem(curr_state);
    var sol = Solver.a_star_search(problem);
    var result = "<ol>";
    for (var i = 0; i < sol.length; i++) {
        var n = moveNumb(sol[i], curr_state);
        curr_state = problem.result(sol[i], curr_state);
        result += "<li>move " + n + "</li>";
    }
    result += "</ol>";
    document.getElementById("steps").innerHTML = result;
}


function currentState() {
    var result = [];
    for (var i = 0; i < 16; i++) {
        var tmp = document.getElementById(String(i)).innerHTML;
        if (tmp == '') {
            result[i] = 16;
        } else {
            result[i] = Number(tmp);
        }
    }
    return result;
}

function moveNumb(action, state) {
    var i = state.indexOf(16);
    switch (action) {
        case Action.up:
            return state[Util.index(Util.x(i), Util.y(i) - 1)];
        case Action.down:
            return state[Util.index(Util.x(i), Util.y(i) + 1)];
        case Action.right:
            return state[Util.index(Util.x(i) + 1, Util.y(i))];
        case Action.left:
            return state[Util.index(Util.x(i) - 1, Util.y(i))];
    }
}

Array.prototype.clone = function() {
    return this.slice(0);
};
Array.prototype.swap = function(i1, i2) {
    var tmp2 = this.clone();
    var tmp = tmp2[i1];
    tmp2[i1] = tmp2[i2];
    tmp2[i2] = tmp;
    return tmp2;
};


var Problem = function(start_state) {
    this.init_state = start_state;
    return this;
}

Problem.prototype.is_solvable = function(x) {
    x = x.clone();
    x.splice(x.indexOf(16), 1);
    x[15] = 16;
    var c = 0;
    for (var i = 0; i < 15; i++) {
        if (x[i] != i + 1) {
            c++;
            var j = x.indexOf(i + 1);
            x[j] = x[i];
            x[i] = i + 1;
        }
    }
    return c % 2 == 0;
}