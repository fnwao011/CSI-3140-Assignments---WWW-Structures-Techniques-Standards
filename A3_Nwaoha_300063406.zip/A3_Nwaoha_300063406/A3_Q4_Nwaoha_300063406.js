function primeFinder(){
    var flag = new Array(1000);
    for(var i = 0; i < 1000; i++){
        flag[i] = true;
    }
    for(var i = 2; i < 1000; i++){
        if(flag[i] == true){
            for(var j = i + 1; j < 1000; j++){
                if(j % i == 0) {
                    flag[j] = false;
                }
            }
        }
    }
    var temp = '';
    for(var i = 2; i < 1000; i++){
        if(flag[i] == true) {
            temp += i + ", ";
        }
    }
    document.getElementById('primeResult').innerHTML += temp;
}
