var tPosition = 0;
var hPosition = 0;


function write(message) {
	document.getElementById('consolelog').innerHTML+= '<br />' + message;
}

// print the positions and such
function showRace() {
	var track = document.getElementById('track');
	var temp = ' '; // space to fit the OUCH!!!

	for(i = 0; i < 70; ++i) {
		if(tPosition == i && hPosition == tPosition) {
			temp = temp.substring(0, temp.length-1) + 'OUCH!!!';
			i+= 2;
		}
		else if(i == tPosition)
			temp+= 'T';
		else if(i == hPosition)
			temp+= 'H';
		else
			temp+= ' ';
	}

	track.innerHTML = temp; 
}

// start function
function start() {


	tPosition = 0;
	hPosition = 0;

	document.getElementById('consolelog').innerHTML = '';
	document.getElementById('track').innerHTML = ' ';

	write('ON YOUR MARK, GET SET');
	
	write('BANG!!!');
	raceSteps();
	write('AND THEY\'RE OFF!!!');
}


function raceSteps() {

    var hMove = parseInt(Math.random() * 10);
	switch(hMove) {
		case 2: case 3:
			hMove = Math.min(hPosition + 9, 69);
			break;
		case 4:
			hPosition = Math.max(hPosition - 12, 0);
			break;
		case 5: case 6: case 7:
			++hPosition;
			break;
		case 8: case 9:
			hPosition = Math.max(hPosition - 1, 0);
	}

	var tMove = parseInt(Math.random() * 10);
	switch(tMove) {
		case 0: case 1: case 2: case 3: case 4:
			tPosition = Math.min(tPosition + 3, 69);
			break;
		case 5: case 6:
			tPosition = Math.max(tPosition - 6, 0);
			break;
		case 7: case 8: case 9:
			++tPosition;
			break;
	}


	// Prints race to track
	showRace();

	// at the end
	if(tPosition >= 69 && hPosition >= 69)
		write('IT\'S A TIE.');
	else if(tPosition >= 69)
		write('TORTOISE WINS!!! YAY!!!');
	else if(hPosition >= 69)
		write('HARE WINS. YUCK!');
	else {
		setTimeout(raceSteps, 1000);
		return;
	}

	document.getElementById('raceStart').disabled = false;
	
}

